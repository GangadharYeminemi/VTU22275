import json
import datetime
from typing import List, Dict
from flask import Flask, request, jsonify

# LogEntry structure
class LogEntry:
    def __init__(self, stack: List[str] = None, level: str = "", package: str = "", message: str = ""):
        self.stack = stack if stack else []
        self.level = level
        self.package = package
        self.message = message

# local logging
def log(entry: LogEntry) -> None:
    log_data = {
        "timestamp": datetime.datetime.now().isoformat(),
        "stack": entry.stack,
        "level": entry.level,
        "package": entry.package,
        "message": entry.message
    }
    
# Log to console
    print(json.dumps(log_data, indent=2))
    
# it is uswed to save into a log file
    with open("application.log", "a") as log_file:
        log_file.write(json.dumps(log_data) + "\n")

# Logging Middleware class
class LoggingMiddleware:
    def __init__(self, app):
        self.app = app
        self.init_app()

    def init_app(self):
        self.app.before_request(self.log_request)
        self.app.after_request(self.log_response)

    def log_request(self):
        log(LogEntry(
            level="info",
            package="backend",
            message=f"Received request: {request.method} {request.path}"
        ))

    def log_response(self, response):
        log(LogEntry(
            level="info",
            package="backend",
            message=f"Sent response: {response.status_code} for {request.path}"
        ))
        return response

# Flask Application
app = Flask(__name__)
middleware = LoggingMiddleware(app)

# Average Calculator Logic
def calculate_average(numbers: List[float]) -> float:
    if not numbers:
        log(LogEntry(level="error", package="backend", message="Empty list "))
        raise ValueError("Cannot calculate average of an empty list")
    return sum(numbers) / len(numbers)

# API Endpoint
@app.route('/api/average', methods=['POST'])
def get_average():
    try:
        data = request.get_json()
        numbers = data.get('numbers', [])
        if not isinstance(numbers, list):
            log(LogEntry(level="error", package="backend", message="Invalid input: 'numbers' must be a list"))
            return jsonify({"error": "Invalid input: 'numbers' must be a list"}), 400
        
        average = calculate_average([float(x) for x in numbers])
        log(LogEntry(level="info", package="backend", message=f"Calculated average: {average}"))
        return jsonify({"average": average}), 200
    except ValueError as e:
        log(LogEntry(level="error", package="backend", message=f"Calculation error: {str(e)}"))
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        log(LogEntry(level="fatal", package="backend", message=f"Unexpected error: {str(e)}"))
        return jsonify({"error": "Internal server error"}), 500

if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0', port=5000)